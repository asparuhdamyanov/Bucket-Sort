﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void bubbleSort(double[] arr)
        {
            int n = arr.Length;
            for (int i = 0; i < n - 1; i++)
                for (int j = 0; j < n - i - 1; j++)
                    if (arr[j] > arr[j + 1])
                    {
                        double temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
        }
        public static void BucketSort(double[] data, int bucketCount)
        {
            var buckets = new List<double>[bucketCount];
            for (int i = 0; i < bucketCount; i++)
                buckets[i] = new List<double>(data.Length / bucketCount);

            var min = double.MaxValue;
            var max = -double.MaxValue;

            for (int i = 0; i < data.Length; i++)
            {
                min = Math.Min(min, data[i]);
                max = Math.Max(max, data[i]);
            }

            for (int i = 0; i < data.Length; i++)
            {
                var idx = Math.Min(bucketCount - 1, (int)(bucketCount * (data[i] - min) / (max - min)));
                buckets[idx].Add(data[i]);
            }

            Parallel.For(0, bucketCount, i => buckets[i].Sort());

            var index = 0;
            for (var i = 0; i < bucketCount; i++)
                for (var j = 0; j < buckets[i].Count; j++)
                    data[index++] = buckets[i][j];
        }

        public static void Main(string[] args)
        {
           
                double[] arr = { (double)0.897, (double)0.565,
                   (double)0.656, (double)0.1234,
                   (double)0.665, (double)0.3434,
                };

                int n = arr.Length;
            
              
                        BucketSort(arr, n);
                Console.WriteLine("Sorted array is ");  
                foreach (double el in arr)
                {
                    Console.Write(el + " ");
                }
            
        }
    }
}

