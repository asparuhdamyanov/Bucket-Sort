﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bucketUI
{
    public partial class Form1 : Form
    {
        string getString(double[] arr)
        {
            String str = null;
            foreach (double d in arr)
            {
                str += d.ToString() + ", ";
            }
            return str;
        }
        public static void BucketSort(double[] data, int bucketCount)
        {
            var buckets = new List<double>[bucketCount];
            for (int i = 0; i < bucketCount; i++)
                buckets[i] = new List<double>(data.Length / bucketCount);

            var min = double.MaxValue;
            var max = -double.MaxValue;

            for (int i = 0; i < data.Length; i++)
            {
                min = Math.Min(min, data[i]);
                max = Math.Max(max, data[i]);
            }

            for (int i = 0; i < data.Length; i++)
            {
                var idx = Math.Min(bucketCount - 1, (int)(bucketCount * (data[i] - min) / (max - min)));
                buckets[idx].Add(data[i]);
            }

            Parallel.For(0, bucketCount, i => buckets[i].Sort());

            var index = 0;
            for (var i = 0; i < bucketCount; i++)
                for (var j = 0; j < buckets[i].Count; j++)
                    data[index++] = buckets[i][j];
        }

        public Form1()
        {
            InitializeComponent();


        }
        private void button1_Click(object sender, EventArgs e)
        {
            string inner = array.Text;
            string[] words = inner.Split(',');
            int n = words.Length;
            double[] arr = new double[n];
            for (int i=0;i<n;i++)
            {
                arr[i] = double.Parse(words[i]);
            }
            BucketSort(arr, n);
            string sorted = getString(arr);

            sortedArray.Text = sorted;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
